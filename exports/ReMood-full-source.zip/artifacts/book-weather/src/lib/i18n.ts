export type Lang = "ar" | "en" | "fr";

export const LANGUAGES: { id: Lang; label: string; flag: string; dir: "rtl" | "ltr" }[] = [
  { id: "ar", label: "العربية",  flag: "🇸🇦", dir: "rtl" },
  { id: "en", label: "English",  flag: "🇬🇧", dir: "ltr" },
  { id: "fr", label: "Français", flag: "🇫🇷", dir: "ltr" },
];

export const T: Record<Lang, Record<string, string>> = {
  ar: {
    subtitle:           "رفيقك الشخصي لاختيار الكتاب المناسب لمزاجك",
    whereAreYou:        "أين أنت الآن؟",
    yourWeather:        "طقس مدينتك",
    weatherError:       "تعذّر جلب بيانات الطقس",
    goodreads:          "ربط حساب Goodreads",
    howFeel:            "كيف تشعر الآن؟",
    whatRead:           "ماذا تريد أن تقرأ؟",
    readingTime:        "كم وقتك للقراءة؟",
    ageGroup:           "فئتك العمرية",
    occasion:           "مناسبة خاصة",
    season:             "الفصل الحالي",
    generate:           "رشّح لي كتاباً الآن",
    generating:         "جاري اختيار كتابك…",
    readOrListen:       "اقرأ أو استمع",
    whyThisBook:        "لماذا هذا الكتاب؟",
    iWantToRead:        "أريد قراءته",
    removeImage:        "إزالة الصورة",
    customBg:           "خلفية خاصة",
    excludeNote:        "سيستثني {n} كتاباً قرأتها من Goodreads",
    morning:            "صباح القراءة ☀️",
    afternoon:          "وقت الكتاب 📖",
    evening:            "مساء الأفكار 🌆",
    night:              "ليلة القارئ 🌙",
    short:              "📖 قصير — أقل من 250 صفحة",
    anyLength:          "📚 أي طول يناسبني",
    long:               "📕 طويل — أكثر من 350 صفحة",
    noOccasion:         "لا مناسبة محددة",
    autoOccasion:       "مناسبة مكتشفة تلقائياً",
    occasionBanner:     "كتب مقترحة لـ",
    seasonSpring:       "🌸 الربيع",
    seasonSummer:       "☀️ الصيف",
    seasonAutumn:       "🍂 الخريف",
    seasonWinter:       "❄️ الشتاء",
    // Goodreads component
    grTitle:            "ربط حساب Goodreads",
    grDesc:             "أدخل معرّفك الرقمي على Goodreads حتى يتجنّب الذكاء الاصطناعي اقتراح كتب قرأتها، ويتيح لك إضافة توصيات جديدة لقائمة \"أريد القراءة\".",
    grHowLabel:         "كيف أجد معرّفي الرقمي؟",
    grHowBody:          "افتح ملفك الشخصي على Goodreads → الرابط سيكون بالشكل:",
    grHowPublic:        "تأكد من أن ملفك الشخصي عام.",
    grConnect:          "ربط",
    grLoading:          "جاري تحميل رف القراءة…",
    grError:            "تعذّر جلب البيانات",
    grLoaded:           "{n} كتاب مقروء محمّل",
    grShowBooks:        "عرض الكتب",
    grDisconnect:       "فصل الحساب",
    grErrorHint:        "تأكد أن المعرّف صحيح وأن الملف الشخصي عام على Goodreads.",
    grReadList:         "كتب مقروءة — سيتجنّبها الذكاء الاصطناعي",
    grMoreBooks:        "… و{n} كتاب آخر",
    grActiveNote:       "✓ الذكاء الاصطناعي سيستثني كتبك المقروءة تلقائياً عند التوصية",
    bookLangLabel:      "لغة الكتاب",
    bookLangAuto:       "تلقائي",
  },
  en: {
    subtitle:           "Your personal guide to the perfect book for your mood",
    whereAreYou:        "Where are you?",
    yourWeather:        "Your weather",
    weatherError:       "Could not load weather",
    goodreads:          "Connect Goodreads",
    howFeel:            "How do you feel?",
    whatRead:           "What do you want to read?",
    readingTime:        "How much time do you have?",
    ageGroup:           "Your age group",
    occasion:           "Special occasion",
    season:             "Current season",
    generate:           "Recommend me a book",
    generating:         "Finding your book…",
    readOrListen:       "Read or Listen",
    whyThisBook:        "Why this book?",
    iWantToRead:        "I want to read it",
    removeImage:        "Remove image",
    customBg:           "Custom background",
    excludeNote:        "Excluding {n} books you've read on Goodreads",
    morning:            "Good Morning ☀️",
    afternoon:          "Afternoon Read 📖",
    evening:            "Evening Thoughts 🌆",
    night:              "Night Reader 🌙",
    short:              "📖 Short — under 250 pages",
    anyLength:          "📚 Any length works",
    long:               "📕 Long — over 350 pages",
    noOccasion:         "No special occasion",
    autoOccasion:       "Auto-detected occasion",
    occasionBanner:     "Books suggested for",
    seasonSpring:       "🌸 Spring",
    seasonSummer:       "☀️ Summer",
    seasonAutumn:       "🍂 Autumn",
    seasonWinter:       "❄️ Winter",
    // Goodreads component
    grTitle:            "Connect Goodreads",
    grDesc:             "Enter your Goodreads user ID so the AI avoids recommending books you've already read, and lets you add new picks to your \"Want to Read\" list.",
    grHowLabel:         "How do I find my user ID?",
    grHowBody:          "Open your Goodreads profile → the URL will look like:",
    grHowPublic:        "Make sure your profile is set to public.",
    grConnect:          "Connect",
    grLoading:          "Loading your reading shelf…",
    grError:            "Could not fetch data",
    grLoaded:           "{n} books read — loaded",
    grShowBooks:        "Show books",
    grDisconnect:       "Disconnect",
    grErrorHint:        "Make sure the ID is correct and your Goodreads profile is public.",
    grReadList:         "Books you've read — the AI will skip these",
    grMoreBooks:        "… and {n} more",
    grActiveNote:       "✓ The AI will automatically skip your read books when recommending",
    bookLangLabel:      "Book Language",
    bookLangAuto:       "Auto",
  },
  fr: {
    subtitle:           "Votre guide personnel pour le livre parfait selon votre humeur",
    whereAreYou:        "Où êtes-vous ?",
    yourWeather:        "Votre météo",
    weatherError:       "Impossible de charger la météo",
    goodreads:          "Connecter Goodreads",
    howFeel:            "Comment vous sentez-vous ?",
    whatRead:           "Que voulez-vous lire ?",
    readingTime:        "Combien de temps avez-vous ?",
    ageGroup:           "Votre groupe d'âge",
    occasion:           "Occasion spéciale",
    season:             "Saison actuelle",
    generate:           "Recommandez-moi un livre",
    generating:         "Recherche de votre livre…",
    readOrListen:       "Lire ou Écouter",
    whyThisBook:        "Pourquoi ce livre ?",
    iWantToRead:        "Je veux le lire",
    removeImage:        "Supprimer l'image",
    customBg:           "Fond personnalisé",
    excludeNote:        "Exclure {n} livres lus sur Goodreads",
    morning:            "Bonne Matinée ☀️",
    afternoon:          "Lecture de l'après-midi 📖",
    evening:            "Soirée de réflexion 🌆",
    night:              "Lecteur de nuit 🌙",
    short:              "📖 Court — moins de 250 pages",
    anyLength:          "📚 Toute longueur",
    long:               "📕 Long — plus de 350 pages",
    noOccasion:         "Aucune occasion spéciale",
    autoOccasion:       "Occasion détectée automatiquement",
    occasionBanner:     "Livres suggérés pour",
    seasonSpring:       "🌸 Printemps",
    seasonSummer:       "☀️ Été",
    seasonAutumn:       "🍂 Automne",
    seasonWinter:       "❄️ Hiver",
    // Goodreads component
    grTitle:            "Connecter Goodreads",
    grDesc:             "Entrez votre identifiant Goodreads pour que l'IA évite de suggérer des livres que vous avez déjà lus, et pour ajouter de nouvelles recommandations à votre liste \"Je veux lire\".",
    grHowLabel:         "Comment trouver mon identifiant ?",
    grHowBody:          "Ouvrez votre profil Goodreads → l'URL ressemble à :",
    grHowPublic:        "Assurez-vous que votre profil est public.",
    grConnect:          "Connecter",
    grLoading:          "Chargement de votre bibliothèque…",
    grError:            "Impossible de récupérer les données",
    grLoaded:           "{n} livres lus — chargés",
    grShowBooks:        "Voir les livres",
    grDisconnect:       "Déconnecter",
    grErrorHint:        "Vérifiez que l'identifiant est correct et que votre profil Goodreads est public.",
    grReadList:         "Livres lus — l'IA les ignorera",
    grMoreBooks:        "… et {n} de plus",
    grActiveNote:       "✓ L'IA exclura automatiquement vos livres lus lors des recommandations",
    bookLangLabel:      "Langue du livre",
    bookLangAuto:       "Auto",
  },
};

// ── Occasions ─────────────────────────────────────────────────────────────────
export type OccasionId =
  | "none" | "ramadan" | "eid_fitr" | "eid_adha" | "new_year"
  | "valentine" | "world_book_day" | "saudi_national_day"
  | "halloween" | "christmas" | "thanksgiving" | "mothers_day"
  | "summer_vacation" | "autumn_vacation" | "winter_vacation" | "spring_vacation";

export const OCCASIONS: Record<Lang, { id: OccasionId; label: string }[]> = {
  ar: [
    { id: "none",              label: "لا مناسبة محددة" },
    { id: "ramadan",           label: "رمضان الكريم 🌙" },
    { id: "eid_fitr",          label: "عيد الفطر 🎊" },
    { id: "eid_adha",          label: "عيد الأضحى 🐑" },
    { id: "new_year",          label: "رأس السنة الجديدة 🎆" },
    { id: "valentine",         label: "يوم الحب 💕" },
    { id: "world_book_day",    label: "اليوم العالمي للكتاب 📚" },
    { id: "saudi_national_day",label: "اليوم الوطني السعودي 🇸🇦" },
    { id: "halloween",         label: "هالوين 🎃" },
    { id: "christmas",         label: "عيد الميلاد 🎄" },
    { id: "thanksgiving",      label: "يوم الشكر 🦃" },
    { id: "mothers_day",       label: "يوم الأم 💐" },
    { id: "summer_vacation",   label: "إجازة الصيف ☀️" },
    { id: "autumn_vacation",   label: "إجازة الخريف 🍂" },
    { id: "winter_vacation",   label: "إجازة الشتاء ❄️" },
    { id: "spring_vacation",   label: "إجازة الربيع 🌸" },
  ],
  en: [
    { id: "none",              label: "No special occasion" },
    { id: "ramadan",           label: "Ramadan 🌙" },
    { id: "eid_fitr",          label: "Eid Al-Fitr 🎊" },
    { id: "eid_adha",          label: "Eid Al-Adha 🐑" },
    { id: "new_year",          label: "New Year 🎆" },
    { id: "valentine",         label: "Valentine's Day 💕" },
    { id: "world_book_day",    label: "World Book Day 📚" },
    { id: "saudi_national_day",label: "Saudi National Day 🇸🇦" },
    { id: "halloween",         label: "Halloween 🎃" },
    { id: "christmas",         label: "Christmas 🎄" },
    { id: "thanksgiving",      label: "Thanksgiving Day 🦃" },
    { id: "mothers_day",       label: "Mother's Day 💐" },
    { id: "summer_vacation",   label: "Summer Vacation ☀️" },
    { id: "autumn_vacation",   label: "Autumn Vacation 🍂" },
    { id: "winter_vacation",   label: "Winter Vacation ❄️" },
    { id: "spring_vacation",   label: "Spring Vacation 🌸" },
  ],
  fr: [
    { id: "none",              label: "Aucune occasion" },
    { id: "ramadan",           label: "Ramadan 🌙" },
    { id: "eid_fitr",          label: "Aïd El-Fitr 🎊" },
    { id: "eid_adha",          label: "Aïd El-Adha 🐑" },
    { id: "new_year",          label: "Nouvel An 🎆" },
    { id: "valentine",         label: "Saint-Valentin 💕" },
    { id: "world_book_day",    label: "Journée Mondiale du Livre 📚" },
    { id: "saudi_national_day",label: "Fête Nationale Saoudienne 🇸🇦" },
    { id: "halloween",         label: "Halloween 🎃" },
    { id: "christmas",         label: "Noël 🎄" },
    { id: "thanksgiving",      label: "Jour de Grâce 🦃" },
    { id: "mothers_day",       label: "Fête des Mères 💐" },
    { id: "summer_vacation",   label: "Vacances d'Été ☀️" },
    { id: "autumn_vacation",   label: "Vacances d'Automne 🍂" },
    { id: "winter_vacation",   label: "Vacances d'Hiver ❄️" },
    { id: "spring_vacation",   label: "Vacances de Printemps 🌸" },
  ],
};

// ── Age Groups ────────────────────────────────────────────────────────────────
export const AGE_GROUPS: Record<Lang, { id: string; label: string }[]> = {
  ar: [
    { id: "children",    label: "أطفال 🧒 (8-12)" },
    { id: "teen",        label: "مراهقون 🎒 (13-17)" },
    { id: "young_adult", label: "شباب ✨ (18-30)" },
    { id: "adult",       label: "بالغون 📚 (31-55)" },
    { id: "senior",      label: "كبار السن 🌟 (+55)" },
  ],
  en: [
    { id: "children",    label: "Children 🧒 (8-12)" },
    { id: "teen",        label: "Teenagers 🎒 (13-17)" },
    { id: "young_adult", label: "Young Adults ✨ (18-30)" },
    { id: "adult",       label: "Adults 📚 (31-55)" },
    { id: "senior",      label: "Senior Readers 🌟 (55+)" },
  ],
  fr: [
    { id: "children",    label: "Enfants 🧒 (8-12)" },
    { id: "teen",        label: "Adolescents 🎒 (13-17)" },
    { id: "young_adult", label: "Jeunes adultes ✨ (18-30)" },
    { id: "adult",       label: "Adultes 📚 (31-55)" },
    { id: "senior",      label: "Séniors 🌟 (+55)" },
  ],
};

// ── Season detection ──────────────────────────────────────────────────────────
export type Season = "spring" | "summer" | "autumn" | "winter";

export function detectSeason(): Season {
  const m = new Date().getMonth() + 1;
  if (m >= 3 && m <= 5) return "spring";
  if (m >= 6 && m <= 8) return "summer";
  if (m >= 9 && m <= 11) return "autumn";
  return "winter";
}

// ── Occasion auto-detection ───────────────────────────────────────────────────
export function detectOccasion(): OccasionId {
  const now = new Date();
  const m = now.getMonth() + 1;
  const d = now.getDate();

  if (m === 1  && d <= 3)                      return "new_year";
  if (m === 2  && d === 14)                    return "valentine";
  if (m === 3  && d >= 10 && d <= 20)          return "mothers_day";   // approximate
  if (m === 4  && d === 23)                    return "world_book_day";
  if (m >= 6   && m <= 8)                      return "summer_vacation";
  if (m === 9  && d >= 22 && d <= 30)          return "autumn_vacation";
  if (m === 9  && d === 23)                    return "saudi_national_day";
  if (m === 10 && d === 31)                    return "halloween";
  if (m === 10 && d >= 15 && d <= 31)          return "autumn_vacation";
  if (m === 11 && d >= 22 && d <= 28)          return "thanksgiving";
  if (m === 12 && d >= 20 && d <= 31)          return "winter_vacation";
  if (m === 3  && d >= 22 && d <= 31)          return "spring_vacation";
  if (m === 4  && d >= 1  && d <= 15)          return "spring_vacation";
  if (m === 12 && d >= 24 && d <= 26)          return "christmas";
  // Ramadan 2026: approx Feb 17 – Mar 18
  if ((m === 2 && d >= 17) || (m === 3 && d <= 18)) return "ramadan";
  // Eid Al-Fitr 2026: approx Mar 19-21
  if (m === 3  && d >= 19 && d <= 21)         return "eid_fitr";
  // Eid Al-Adha 2026: approx May 26-30
  if (m === 5  && d >= 26 && d <= 30)         return "eid_adha";

  return "none";
}
