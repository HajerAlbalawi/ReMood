import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useGetGoodreadsShelf } from "@workspace/api-client-react";
import { BookMarked, Link2, Unlink, CheckCircle, Loader2, AlertCircle, ChevronDown, ChevronUp, X } from "lucide-react";
import { T } from "@/lib/i18n";
import type { Lang } from "@/lib/i18n";

const STORAGE_KEY = "goodreads_user_id";

interface Props {
  onReadBooksChange: (titles: string[]) => void;
  lang: Lang;
}

export function GoodreadsConnect({ onReadBooksChange, lang }: Props) {
  const t = T[lang];
  const isRtl = lang === "ar";

  const [inputId, setInputId]       = useState("");
  const [connectedId, setConnectedId] = useState<string>(() => localStorage.getItem(STORAGE_KEY) ?? "");
  const [showBooks, setShowBooks]   = useState(false);

  const { data, isLoading, isError, error } = useGetGoodreadsShelf(
    { userId: connectedId, shelf: "read" },
    { query: { enabled: !!connectedId, staleTime: 5 * 60 * 1000, retry: 1 } }
  );

  useEffect(() => {
    if (data?.books) onReadBooksChange(data.books.map((b) => b.title));
    else onReadBooksChange([]);
  }, [data, onReadBooksChange]);

  const handleConnect = () => {
    const id = inputId.trim(); if (!id) return;
    setConnectedId(id); localStorage.setItem(STORAGE_KEY, id); setInputId("");
  };
  const handleDisconnect = () => {
    setConnectedId(""); localStorage.removeItem(STORAGE_KEY); onReadBooksChange([]); setShowBooks(false);
  };

  // ── Not connected ────────────────────────────────────────────────────────────
  if (!connectedId) {
    return (
      <motion.div
        className="backdrop-blur-md bg-white/10 border border-white/15 rounded-2xl p-5"
        initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
        dir={isRtl ? "rtl" : "ltr"}
      >
        <div className="flex items-center gap-2 mb-3">
          <BookMarked className="w-5 h-5 text-amber-300 flex-shrink-0" />
          <h2 className="text-base font-semibold text-amber-300">{t.grTitle}</h2>
        </div>

        <p className="text-white/60 text-sm mb-4 leading-relaxed">{t.grDesc}</p>

        {/* How to find user ID */}
        <details className="mb-4 group">
          <summary className="text-xs text-white/40 cursor-pointer hover:text-white/60 transition-colors select-none">
            {t.grHowLabel}
          </summary>
          <div className="mt-2 text-xs text-white/50 leading-relaxed bg-black/20 rounded-lg p-3 border border-white/5">
            {t.grHowBody}<br />
            <span className="font-mono text-amber-300/70" dir="ltr">
              goodreads.com/user/show/<strong>12345678</strong>-name
            </span><br />
            {t.grHowPublic}
          </div>
        </details>

        <div className="flex gap-2" dir="ltr">
          <input
            type="text" value={inputId}
            onChange={(e) => setInputId(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleConnect()}
            placeholder="123456789"
            className="flex-1 bg-black/30 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm outline-none focus:border-amber-400/50 transition-colors placeholder:text-white/25"
          />
          <button
            onClick={handleConnect} disabled={!inputId.trim()}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-400 text-slate-900 font-semibold text-sm disabled:opacity-40 hover:bg-amber-300 transition-colors"
          >
            <Link2 className="w-4 h-4" />
            {t.grConnect}
          </button>
        </div>
      </motion.div>
    );
  }

  // ── Connected ────────────────────────────────────────────────────────────────
  return (
    <motion.div
      className="backdrop-blur-md bg-white/10 border border-white/15 rounded-2xl overflow-hidden"
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
      dir={isRtl ? "rtl" : "ltr"}
    >
      <div className="flex items-center gap-3 p-4">
        <div className="w-8 h-8 rounded-full bg-amber-400/15 flex items-center justify-center flex-shrink-0">
          <BookMarked className="w-4 h-4 text-amber-300" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            {isLoading
              ? <Loader2 className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              : isError
              ? <AlertCircle className="w-3.5 h-3.5 text-red-400" />
              : <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />}
            <span className="text-sm font-medium text-white">
              {isLoading
                ? t.grLoading
                : isError
                ? t.grError
                : t.grLoaded.replace("{n}", String(data?.total ?? 0))}
            </span>
          </div>
          <p className="text-xs text-white/40 font-mono mt-0.5 truncate" dir="ltr">ID: {connectedId}</p>
        </div>

        {!isError && data && data.total > 0 && (
          <button
            onClick={() => setShowBooks((v) => !v)}
            className="text-white/40 hover:text-white/70 transition-colors p-1"
            title={t.grShowBooks}
          >
            {showBooks ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        )}

        <button
          onClick={handleDisconnect}
          className="text-white/30 hover:text-red-400 transition-colors p-1"
          title={t.grDisconnect}
        >
          <Unlink className="w-4 h-4" />
        </button>
      </div>

      {isError && (
        <div className="px-4 pb-4 text-xs text-red-300/80 leading-relaxed">
          {(error as { message?: string })?.message ?? t.grErrorHint}
        </div>
      )}

      <AnimatePresence>
        {showBooks && data && data.books.length > 0 && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="border-t border-white/10 px-4 pb-4 pt-3 max-h-52 overflow-y-auto space-y-1.5">
              <p className="text-xs text-white/40 mb-2">{t.grReadList}</p>
              {data.books.slice(0, 50).map((book) => (
                <div key={book.goodreadsId} className="flex items-center gap-2 text-xs text-white/70">
                  <X className="w-3 h-3 text-red-400/60 flex-shrink-0" />
                  <span className="truncate">{book.title}</span>
                  <span className="text-white/30 truncate">— {book.author}</span>
                </div>
              ))}
              {data.total > 50 && (
                <p className="text-xs text-white/30 pt-1">{t.grMoreBooks.replace("{n}", String(data.total - 50))}</p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!isLoading && !isError && (
        <div className="px-4 pb-3">
          <p className="text-xs text-emerald-400/70">{t.grActiveNote}</p>
        </div>
      )}
    </motion.div>
  );
}
