import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  useGetWeather, getGetWeatherQueryKey, useCreateRecommendation,
} from "@workspace/api-client-react";
import { CITIES, MOODS, CATEGORIES, getCityBookLang, getCityFlag, getCityLocalTime, getCityTimeOfDay, getCityDisplayName, CHILDREN_SECTION_START } from "@/lib/constants";
import {
  LANGUAGES, AGE_GROUPS, OCCASIONS, T, detectSeason, detectOccasion,
  type Lang, type OccasionId, type Season,
} from "@/lib/i18n";
import { WeatherBackground, type TimeOfDay, type BookAtmosphere } from "@/components/weather/WeatherBackground";
import { AmbientSound, type SoundType } from "@/components/AmbientSound";
import { ReadingTimer } from "@/components/ReadingTimer";
import { GoodreadsConnect } from "@/components/GoodreadsConnect";
import { WisdomQuote } from "@/components/WisdomQuote";
import {
  MapPin, Sparkles, Droplets, Thermometer, Wind,
  Compass, BookOpen, Quote, Cloud, ExternalLink,
  BookPlus, Camera, X, BookMarked, Headphones, Globe, Users, Calendar, ChevronDown, Clock,
} from "lucide-react";

// ── Helpers ───────────────────────────────────────────────────────────────────
function getTimeOfDay(): TimeOfDay {
  const h = new Date().getHours();
  if (h >= 5  && h < 12) return "morning";
  if (h >= 12 && h < 17) return "afternoon";
  if (h >= 17 && h < 21) return "evening";
  return "night";
}

const ATMOS_LABELS: Record<string, Record<Lang, string>> = {
  adventure:     { ar: "🗺️ مغامرة",    en: "🗺️ Adventure",   fr: "🗺️ Aventure" },
  mystery:       { ar: "🔍 غموض",      en: "🔍 Mystery",      fr: "🔍 Mystère" },
  thriller:      { ar: "😱 إثارة",     en: "😱 Thriller",     fr: "😱 Thriller" },
  romance:       { ar: "💕 رومانسي",   en: "💕 Romance",      fr: "💕 Romance" },
  family:        { ar: "👨‍👩‍👧 عائلي",    en: "👨‍👩‍👧 Family",     fr: "👨‍👩‍👧 Famille" },
  scifi:         { ar: "🚀 خيال علمي", en: "🚀 Sci-Fi",       fr: "🚀 Sci-Fi" },
  philosophical: { ar: "💭 فلسفي",     en: "💭 Philosophical", fr: "💭 Philosophique" },
  spiritual:     { ar: "🕌 روحي",      en: "🕌 Spiritual",    fr: "🕌 Spirituel" },
  poetry:        { ar: "🖊️ شعري",      en: "🖊️ Poetry",       fr: "🖊️ Poésie" },
  selfhelp:      { ar: "🌟 تطوير",     en: "🌟 Self-Help",    fr: "🌟 Développement" },
  history:       { ar: "🏛️ تاريخي",    en: "🏛️ Historical",   fr: "🏛️ Historique" },
  science:       { ar: "🔬 علمي",      en: "🔬 Science",      fr: "🔬 Science" },
  classic:       { ar: "📖 كلاسيكي",   en: "📖 Classic",      fr: "📖 Classique" },
};

function bookLinks(title: string, author: string) {
  const q  = encodeURIComponent(`${title} ${author}`);
  const qt = encodeURIComponent(title);
  return {
    libby:      `https://libbyapp.com/search/losangeles/search/query-${qt}`,
    storytel:   `https://www.storytel.com/search?q=${q}`,
    audible:    `https://www.audible.com/search?keywords=${q}`,
    kindle:     `https://www.amazon.com/s?k=${q}&i=digital-text`,
    googlePlay: `https://play.google.com/store/search?q=${q}&c=books`,
    gutenberg:  `https://www.gutenberg.org/ebooks/search/?query=${qt}`,
    kobo:       `https://www.kobo.com/search?query=${q}`,
  };
}

function deriveSoundType(conditionGroup: string, tod: TimeOfDay): SoundType {
  if (conditionGroup === "Rain" || conditionGroup === "Drizzle" || conditionGroup === "Thunderstorm") return "rain";
  if (tod === "morning") return "birds";
  if (tod === "night" || tod === "evening") return "wind";
  return "birds";
}

const SEASON_ICONS: Record<Season, string> = {
  spring: "🌸", summer: "☀️", autumn: "🍂", winter: "❄️",
};

type ShowcaseConfig = {
  city: string;
  lang: Lang;
  bookLang: Lang;
  season: Season;
  timeOfDay: TimeOfDay;
  localTime: string;
  conditionGroup: string;
  condition: string;
  temperature: number;
};

const SHOWCASE_CONFIGS: Record<string, ShowcaseConfig> = {
  "spring-paris": { city: "باريس", lang: "fr", bookLang: "fr", season: "spring", timeOfDay: "morning", localTime: "09:15", conditionGroup: "Rain", condition: "Pluie légère", temperature: 13 },
  "summer-riyadh": { city: "الرياض", lang: "ar", bookLang: "ar", season: "summer", timeOfDay: "afternoon", localTime: "15:40", conditionGroup: "Clear", condition: "سماء صافية تماماً", temperature: 45 },
  "autumn-london": { city: "لندن", lang: "en", bookLang: "en", season: "autumn", timeOfDay: "evening", localTime: "18:25", conditionGroup: "Clouds", condition: "Overcast clouds", temperature: 14 },
  "winter-moscow": { city: "موسكو", lang: "en", bookLang: "en", season: "winter", timeOfDay: "night", localTime: "22:10", conditionGroup: "Snow", condition: "Light snow", temperature: -8 },
  "rain-jeddah": { city: "جدة", lang: "ar", bookLang: "ar", season: "summer", timeOfDay: "evening", localTime: "19:05", conditionGroup: "Rain", condition: "زخات مطرية", temperature: 29 },
  "cloudy-berlin": { city: "برلين", lang: "en", bookLang: "en", season: "autumn", timeOfDay: "afternoon", localTime: "14:30", conditionGroup: "Clouds", condition: "Overcast", temperature: 16 },
  "night-tokyo": { city: "طوكيو", lang: "en", bookLang: "en", season: "spring", timeOfDay: "night", localTime: "00:20", conditionGroup: "Clear", condition: "Clear sky", temperature: 18 },
  "morning-nairobi": { city: "نيروبي", lang: "en", bookLang: "en", season: "summer", timeOfDay: "morning", localTime: "07:45", conditionGroup: "Clear", condition: "Clear sky", temperature: 19 },
  "french-casablanca": { city: "الدار البيضاء", lang: "fr", bookLang: "fr", season: "autumn", timeOfDay: "afternoon", localTime: "16:00", conditionGroup: "Clouds", condition: "Nuageux", temperature: 23 },
  "english-new-york": { city: "نيويورك", lang: "en", bookLang: "en", season: "winter", timeOfDay: "morning", localTime: "08:50", conditionGroup: "Snow", condition: "Snow showers", temperature: -2 },
  "arabic-cairo": { city: "القاهرة", lang: "ar", bookLang: "ar", season: "spring", timeOfDay: "evening", localTime: "18:45", conditionGroup: "Clear", condition: "سماء صافية", temperature: 27 },
  "storm-doha": { city: "الدوحة", lang: "ar", bookLang: "en", season: "winter", timeOfDay: "night", localTime: "21:35", conditionGroup: "Thunderstorm", condition: "عاصفة رعدية", temperature: 20 },
};

const showcaseKey = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("showcase") : null;
const showcaseConfig = showcaseKey ? SHOWCASE_CONFIGS[showcaseKey] : undefined;
const SHOWCASE_RESULTS: Record<string, {
  mood: string;
  category: string;
  moodQuote: string;
  aiAnalysis: string;
  books: Array<{ title: string; author: string; subcategory: string; rating: string; reason: string; quote: string; atmosphere: string; length: string }>;
}> = {
  "spring-paris": {
    mood: "هادئ ومتأمل", category: "روايات رومانسية وعاطفية",
    moodQuote: "Un matin pluvieux de printemps appelle un livre qui laisse place à la rêverie, au rythme des gouttes.",
    aiAnalysis: "J'ai choisi des romans français chaleureux, entre romantisme et douceur, pour accompagner une lecture intime près de la fenêtre.",
    books: [
      { title: "Le Petit Prince", author: "Antoine de Saint-Exupéry", subcategory: "Classique", rating: "4.3", reason: "Un conte délicat et profond pour un matin paisible.", quote: "L'essentiel est invisible pour les yeux.", atmosphere: "philosophical", length: "Court" },
      { title: "Madame Bovary", author: "Gustave Flaubert", subcategory: "Romance", rating: "4.0", reason: "Une prose poétique et une atmosphère française parfaite sous la pluie.", quote: "Elle voulait mourir, mais elle voulait aussi vivre à Paris.", atmosphere: "romance", length: "Long" },
      { title: "À la recherche du temps perdu", author: "Marcel Proust", subcategory: "Réflexion", rating: "4.1", reason: "Une lecture lente, riche en mémoire et en émotions.", quote: "Le véritable voyage de découverte ne consiste pas à chercher de nouveaux paysages.", atmosphere: "philosophical", length: "Long" },
    ],
  },
  "summer-riyadh": {
    mood: "متحمس للقراءة", category: "روايات المغامرة والاستكشاف",
    moodQuote: "حين تشتد الشمس، افتح كتاباً يأخذك إلى عوالم بعيدة دون أن تغادر مكانك.",
    aiAnalysis: "هذه المجموعة مليئة بالحركة والخيال، وتمنحك مغامرة منعشة تناسب أجواء الصيف والنهار الطويل.",
    books: [
      { title: "حول العالم في 80 يوماً", author: "جول فيرن", subcategory: "مغامرة", rating: "4.2", reason: "رحلة سريعة وممتعة حول العالم.", quote: "كل ما هو مستحيل سيظل مستحيلاً حتى يتحقق.", atmosphere: "adventure", length: "طويل" },
      { title: "جزيرة الكنز", author: "روبرت لويس ستيفنسون", subcategory: "مغامرة", rating: "4.1", reason: "كنز وقراصنة وتشويق لقراءة صيفية مثالية.", quote: "السفر يفتح العقل كما تفتح الريح الشراع.", atmosphere: "adventure", length: "قصير" },
      { title: "مئة عام من العزلة", author: "غابرييل غارسيا ماركيز", subcategory: "خيال", rating: "4.4", reason: "عالم ساحر يليق بالهروب من حرارة اليوم.", quote: "لم يمت أحد ما دام هناك من يتذكره.", atmosphere: "adventure", length: "طويل" },
    ],
  },
  "autumn-london": {
    mood: "هادئ ومتأمل", category: "الروايات البوليسية والغموض",
    moodQuote: "Autumn leaves and cloudy skies are the perfect invitation to a mystery solved only on the final page.",
    aiAnalysis: "These autumn recommendations blend London's atmospheric mystery with clever characters for a compelling evening read.",
    books: [
      { title: "Murder on the Orient Express", author: "Agatha Christie", subcategory: "Mystery", rating: "4.3", reason: "A classic puzzle for a quiet, rainy evening.", quote: "The best time to solve a crime is when everyone is asleep.", atmosphere: "mystery", length: "Short" },
      { title: "The Hound of the Baskervilles", author: "Arthur Conan Doyle", subcategory: "Detective", rating: "4.4", reason: "Devon fog and autumn atmosphere on every page.", quote: "The world is full of obvious things which nobody ever observes.", atmosphere: "mystery", length: "Short" },
      { title: "The Name of the Rose", author: "Umberto Eco", subcategory: "Historical", rating: "4.2", reason: "A richly layered investigation for detail lovers.", quote: "Books are not made to be believed, but to be subjected to inquiry.", atmosphere: "mystery", length: "Long" },
    ],
  },
  "winter-moscow": {
    mood: "حزين ويبحث عن إلهام", category: "الروايات التاريخية",
    moodQuote: "On a cold winter night, a great human story can offer the warmth you are looking for.",
    aiAnalysis: "I chose deep Russian literature about loneliness and hope — rewarding companions for a thoughtful read by warm light.",
    books: [
      { title: "Crime and Punishment", author: "Fyodor Dostoevsky", subcategory: "Classic", rating: "4.4", reason: "A profound psychological journey from guilt to redemption.", quote: "Pain and suffering are always inevitable for a large intelligence and a deep heart.", atmosphere: "philosophical", length: "Long" },
      { title: "Anna Karenina", author: "Leo Tolstoy", subcategory: "Romance", rating: "4.3", reason: "A sweeping human epic for a long winter night.", quote: "All happy families are alike; each unhappy family is unhappy in its own way.", atmosphere: "romance", length: "Long" },
      { title: "White Nights", author: "Fyodor Dostoevsky", subcategory: "Romance", rating: "4.2", reason: "A short, intimate story about loneliness and dreams.", quote: "My God, a whole moment of happiness! Is that really too little for the whole of a person's life?", atmosphere: "romance", length: "Short" },
    ],
  },
  "storm-doha": {
    mood: "مشتت الذهن ويريد التركيز", category: "تطوير الذات والنجاح",
    moodQuote: "Amid the thunder, give yourself just one focused chapter; small beginnings create calm.",
    aiAnalysis: "These practical, inspiring books help you organise your thoughts and regain focus, even on the most unsettled days.",
    books: [
      { title: "Atomic Habits", author: "James Clear", subcategory: "Self-Help", rating: "4.5", reason: "Small, practical steps for building a focused reading routine.", quote: "Every action is a vote for the type of person you wish to become.", atmosphere: "selfhelp", length: "Long" },
      { title: "Deep Work", author: "Cal Newport", subcategory: "Productivity", rating: "4.2", reason: "A clear guide to reclaiming attention in a distracted world.", quote: "The ability to concentrate without distraction is a rare and valuable skill.", atmosphere: "selfhelp", length: "Short" },
      { title: "The Subtle Art of Not Giving a F*ck", author: "Mark Manson", subcategory: "Self-Help", rating: "4.0", reason: "A direct perspective that quiets the noise and focuses on what matters.", quote: "The desire for a more positive experience is itself a negative experience.", atmosphere: "selfhelp", length: "Short" },
    ],
  },
};
const showcaseResult = showcaseKey ? SHOWCASE_RESULTS[showcaseKey] : undefined;

// ── Component ─────────────────────────────────────────────────────────────────
export default function Home() {
  const showcaseCity = showcaseConfig && CITIES.find(c => c.name === showcaseConfig.city);
  const [lang, setLang]                         = useState<Lang>(showcaseConfig?.lang ?? "ar");
  const [selectedCity, setSelectedCity]         = useState(showcaseCity ?? CITIES[0]);
  const [selectedMoodIdx, setSelectedMoodIdx]   = useState<number | null>(showcaseConfig ? 0 : null);
  const [selectedCatIdx, setSelectedCatIdx]     = useState<number | null>(showcaseConfig ? 0 : null);
  const [bookLength, setBookLength]             = useState<"short" | "any" | "long">("any");
  const [ageGroup, setAgeGroup]                 = useState<string>("");
  const [occasion, setOccasion]                 = useState<OccasionId>(showcaseConfig ? "none" : detectOccasion);
  const [showOccasionPicker, setShowOccasionPicker] = useState(false);
  const [season]                                = useState<Season>(showcaseConfig?.season ?? detectSeason);
  const [showResults, setShowResults]           = useState(Boolean(showcaseResult));
  const [readBooks, setReadBooks]               = useState<string[]>([]);
  const [userImageUrl, setUserImageUrl]         = useState<string | null>(null);
  const [timeOfDay, setTimeOfDay]               = useState<TimeOfDay>(() => showcaseConfig?.timeOfDay ?? getCityTimeOfDay(selectedCity!.tz));
  const [cityLocalTime, setCityLocalTime]       = useState(() => showcaseConfig?.localTime ?? getCityLocalTime(selectedCity!.tz));
  const [bookAtmosphere, setBookAtmosphere]     = useState<BookAtmosphere>(null);
  const [expandedPlatforms, setExpandedPlatforms] = useState<Set<number>>(new Set());
  const [showLangPicker, setShowLangPicker]     = useState(false);
  const [bookLang, setBookLang]                 = useState<Lang>(() => showcaseConfig?.bookLang ?? getCityBookLang(CITIES[0].name));

  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = T[lang];
  const resultT = T[bookLang];
  const isRtl = lang === "ar";

  // Auto-reset book language when city changes
  useEffect(() => {
    if (!showcaseConfig) setBookLang(getCityBookLang(selectedCity!.name));
  }, [selectedCity]);

  const cityFlag = getCityFlag(selectedCity!.name);

  const BOOK_LANG_OPTIONS: { id: Lang; label: string; shortLabel: string; color: string; activeColor: string }[] = [
    { id: "ar", label: "📚 كتب عربية",      shortLabel: "عربي",    color: "text-white/50 border-white/10 bg-white/5",   activeColor: "text-amber-300 bg-amber-400/15 border-amber-400/40" },
    { id: "en", label: "📚 English Books",   shortLabel: "English", color: "text-white/50 border-white/10 bg-white/5",   activeColor: "text-sky-300 bg-sky-400/15 border-sky-400/40" },
    { id: "fr", label: "📚 Livres français", shortLabel: "Français",color: "text-white/50 border-white/10 bg-white/5",   activeColor: "text-violet-300 bg-violet-400/15 border-violet-400/40" },
  ];
  const activeBookLangOpt = BOOK_LANG_OPTIONS.find(o => o.id === bookLang)!;

  // Always send Arabic mood/category to the API regardless of UI language
  const selectedMood     = selectedMoodIdx !== null ? MOODS.ar[selectedMoodIdx]    : "";
  const selectedCategory = selectedCatIdx  !== null ? CATEGORIES.ar[selectedCatIdx] : "";

  const bookLengthMap: Record<"short" | "any" | "long", string> = {
    short: "قصير", any: "أي طول", long: "طويل",
  };

  const { data: liveWeather, isLoading: liveWeatherLoading, isError: liveWeatherError } = useGetWeather(
    { city: selectedCity!.name, lat: selectedCity!.lat, lng: selectedCity!.lng },
    { query: { enabled: true, queryKey: getGetWeatherQueryKey({ city: selectedCity!.name, lat: selectedCity!.lat, lng: selectedCity!.lng }) } }
  );
  const weather = showcaseConfig
    ? { temperature: showcaseConfig.temperature, condition: showcaseConfig.condition, conditionGroup: showcaseConfig.conditionGroup }
    : liveWeather;
  const weatherLoading = showcaseConfig ? false : liveWeatherLoading;
  const weatherError = showcaseConfig ? false : liveWeatherError;

  const createRec = useCreateRecommendation();
  const recommendation = showcaseResult && showcaseConfig
    ? {
        id: 0,
        city: selectedCity.name,
        mood: selectedMood,
        category: selectedCategory,
        weatherCondition: showcaseConfig.condition,
        temperature: showcaseConfig.temperature,
        books: showcaseResult.books,
        moodQuote: showcaseResult.moodQuote,
        aiAnalysis: showcaseResult.aiAnalysis,
        createdAt: "2026-08-26T00:00:00.000Z",
      }
    : createRec.data;

  useEffect(() => {
    if (createRec.data?.books?.[0]) {
      const first = createRec.data.books[0] as { atmosphere?: string };
      if (first.atmosphere) setBookAtmosphere(first.atmosphere as BookAtmosphere);
    }
  }, [createRec.data]);

  // Change document direction on lang change
  useEffect(() => {
    document.documentElement.setAttribute("dir", isRtl ? "rtl" : "ltr");
  }, [isRtl]);

  // Update timeOfDay + local clock whenever city changes, refresh every minute
  useEffect(() => {
    const update = () => {
      setTimeOfDay(showcaseConfig?.timeOfDay ?? getCityTimeOfDay(selectedCity!.tz));
      setCityLocalTime(showcaseConfig?.localTime ?? getCityLocalTime(selectedCity!.tz));
    };
    update();
    const timer = setInterval(update, 60_000);
    return () => clearInterval(timer);
  }, [selectedCity]);

  const handleReadBooksChange = useCallback((titles: string[]) => setReadBooks(titles), []);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => { if (ev.target?.result) setUserImageUrl(ev.target.result as string); };
    reader.readAsDataURL(file); e.target.value = "";
  };

  const handleGenerate = () => {
    if (!weather || !selectedMood || !selectedCategory) return;
    setShowResults(true); setBookAtmosphere(null);
    createRec.mutate({ data: {
      city: selectedCity!.name, mood: selectedMood, category: selectedCategory,
      weatherCondition: weather.condition, temperature: weather.temperature,
      excludeBooks: readBooks.length > 0 ? readBooks : undefined,
      bookLength: bookLength !== "any" ? bookLengthMap[bookLength] : undefined,
      timeOfDay, cityName: selectedCity!.name,
       // Keep recommendation content in the selected book language. The UI
       // language remains independent and only controls interface labels.
       language: bookLang,
      ageGroup: ageGroup || undefined,
      occasion: occasion !== "none" ? occasion : undefined,
      season,
      cityBookLang: bookLang,
    }});
  };

  const conditionGroup = weather?.conditionGroup ?? "Clear";
  const goodreadsUrl = (title: string, author: string) =>
    `https://www.goodreads.com/search?q=${encodeURIComponent(`${title} ${author}`)}`;

  const greetings: Record<TimeOfDay, string> = {
    morning: t.morning, afternoon: t.afternoon, evening: t.evening, night: t.night,
  };

  const lengthOptions: { key: "short" | "any" | "long"; label: string }[] = [
    { key: "short", label: t.short },
    { key: "any",   label: t.anyLength },
    { key: "long",  label: t.long },
  ];

  const autoDetectedOccasion = occasion !== "none";
  const occasionLabel = OCCASIONS[lang].find(o => o.id === occasion)?.label ?? "";

  return (
    <>
      <WeatherBackground conditionGroup={conditionGroup} category={selectedCategory} userImageUrl={userImageUrl} timeOfDay={timeOfDay} bookAtmosphere={bookAtmosphere} />
      <AmbientSound soundType={deriveSoundType(conditionGroup, timeOfDay)} />
      <ReadingTimer />

      {/* Image upload — top left */}
      <div className="fixed top-4 left-4 z-50 flex items-center gap-2">
        <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
        {userImageUrl ? (
          <motion.button initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }}
            onClick={() => setUserImageUrl(null)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-black/50 border border-white/20 text-white/80 text-xs hover:bg-red-900/50 hover:text-red-300 transition-all backdrop-blur-md">
            <X className="w-3.5 h-3.5" /> {t.removeImage}
          </motion.button>
        ) : (
          <motion.button initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }}
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-black/40 border border-white/15 text-white/70 text-xs hover:bg-white/10 hover:text-white hover:border-white/30 transition-all backdrop-blur-md">
            <Camera className="w-3.5 h-3.5" /> {t.customBg}
          </motion.button>
        )}
      </div>

      <div className={`relative z-10 w-full min-h-screen px-4 py-12 md:px-8 max-w-4xl mx-auto flex flex-col gap-7 ${isRtl ? "" : "font-sans"}`}>

        {/* ── Header ── */}
        <header className="text-center space-y-2 pt-8">
          <motion.div initial={{ opacity: 0, y: -24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9 }}>
            {/* Language + Season row */}
            <div className="flex items-center justify-center gap-3 mb-3">
              {/* Season badge */}
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/30 border border-white/12 text-white/60 text-xs backdrop-blur-sm">
                <span>{t[`season${season.charAt(0).toUpperCase() + season.slice(1)}` as keyof typeof t]}</span>
              </div>

              {/* Language picker */}
              <div className="relative">
                <button onClick={() => setShowLangPicker(p => !p)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/30 border border-white/12 text-white/60 text-xs hover:bg-white/10 hover:text-white transition-all backdrop-blur-sm">
                  <Globe className="w-3 h-3" />
                  <span>{LANGUAGES.find(l => l.id === lang)?.flag}</span>
                  <span>{LANGUAGES.find(l => l.id === lang)?.label}</span>
                  <ChevronDown className={`w-3 h-3 transition-transform ${showLangPicker ? "rotate-180" : ""}`} />
                </button>
                <AnimatePresence>
                  {showLangPicker && (
                    <motion.div initial={{ opacity: 0, y: -6, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -6, scale: 0.96 }}
                      className="absolute top-9 left-1/2 -translate-x-1/2 z-50 bg-black/80 backdrop-blur-xl border border-white/12 rounded-xl overflow-hidden shadow-xl min-w-[140px]">
                      {LANGUAGES.map(l => (
                        <button key={l.id} onClick={() => { setLang(l.id); setShowLangPicker(false); setSelectedMoodIdx(null); setSelectedCatIdx(null); }}
                          className={`w-full flex items-center gap-2 px-3 py-2.5 text-sm transition-colors hover:bg-white/10 ${lang === l.id ? "bg-amber-400/15 text-amber-300" : "text-white/70"}`}>
                          <span>{l.flag}</span><span>{l.label}</span>
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <div className="text-xs text-amber-300/60 mb-2 tracking-widest">{greetings[timeOfDay]}</div>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-br from-amber-200 via-amber-400 to-orange-500">
              ReMood
            </h1>
            <p className="text-white/65 mt-2 text-base md:text-lg font-light">{t.subtitle}</p>
          </motion.div>
        </header>

        {/* ── Wisdom Quote ── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="backdrop-blur-md bg-black/25 border border-white/8 rounded-2xl px-4 pt-4 pb-7"
        >
          <WisdomQuote lang={lang} isRtl={isRtl} />
        </motion.div>

        {/* ── Occasion Banner ── */}
        <AnimatePresence>
          {autoDetectedOccasion && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              className="backdrop-blur-md bg-amber-400/10 border border-amber-400/25 p-4 rounded-2xl flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-amber-300 flex-shrink-0" />
                <div>
                  <div className="text-xs text-amber-400/70">{t.autoOccasion}</div>
                  <div className="text-sm font-semibold text-amber-200">{occasionLabel}</div>
                </div>
              </div>
              <button onClick={() => setShowOccasionPicker(p => !p)}
                className="text-xs text-white/40 hover:text-white/70 transition-colors underline underline-offset-2">
                {showOccasionPicker ? "▲" : t.occasion + " ▼"}
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Occasion picker */}
        <AnimatePresence>
          {showOccasionPicker && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
              className="backdrop-blur-md bg-white/6 border border-white/10 p-4 rounded-2xl">
              <div className="text-sm font-semibold text-amber-300 mb-3 flex items-center gap-2"><Calendar className="w-4 h-4" />{t.occasion}</div>
              <div className="flex flex-wrap gap-2">
                {OCCASIONS[lang].map(o => (
                  <button key={o.id} onClick={() => { setOccasion(o.id as OccasionId); setShowOccasionPicker(false); }}
                    className={`text-xs px-3 py-1.5 rounded-full border transition-all whitespace-nowrap ${
                      occasion === o.id
                        ? "bg-amber-400 text-slate-900 border-amber-400"
                        : "bg-black/20 border-white/10 text-white/70 hover:bg-white/10"}`}>
                    {o.label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── City & Weather ── */}
        <motion.div className="grid grid-cols-1 md:grid-cols-2 gap-4"
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <div className="backdrop-blur-md bg-white/8 border border-white/12 p-5 rounded-2xl flex flex-col gap-3">
            <h2 className="text-sm font-semibold flex items-center gap-2 text-amber-300"><MapPin className="w-4 h-4" />{t.whereAreYou}</h2>
            <select className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-white appearance-none outline-none focus:border-amber-400/50 transition-colors text-sm"
              value={selectedCity!.name}
              onChange={(e) => { const c = CITIES.find(x => x.name === e.target.value); if (c) setSelectedCity(c); }}>
              {CITIES.map(c => <option key={c.name} value={c.name} className="bg-slate-900 text-white">{getCityFlag(c.name)} {getCityDisplayName(c.name, lang)}</option>)}
            </select>
            {/* Local time + time of day */}
            <motion.div
              key={`${selectedCity!.name}-time`}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2"
            >
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs border font-mono font-semibold bg-indigo-500/10 border-indigo-400/25 text-indigo-300">
                <Clock className="w-3 h-3" />
                {cityLocalTime}
              </div>
              <div className={`px-2.5 py-1 rounded-full text-xs border font-medium
                ${timeOfDay === "morning"   ? "bg-orange-400/10 border-orange-400/25 text-orange-300" :
                  timeOfDay === "afternoon" ? "bg-yellow-400/10 border-yellow-400/25 text-yellow-300" :
                  timeOfDay === "evening"   ? "bg-purple-400/10 border-purple-400/25 text-purple-300" :
                                              "bg-slate-500/10 border-slate-400/25 text-slate-300"}`}>
                {timeOfDay === "morning"   ? (lang === "ar" ? "🌅 صباح" : lang === "fr" ? "🌅 Matin"   : "🌅 Morning")   :
                 timeOfDay === "afternoon" ? (lang === "ar" ? "☀️ نهار"  : lang === "fr" ? "☀️ Après-midi" : "☀️ Afternoon") :
                 timeOfDay === "evening"   ? (lang === "ar" ? "🌆 مساء"  : lang === "fr" ? "🌆 Soir"    : "🌆 Evening")   :
                                            (lang === "ar" ? "🌙 ليل"   : lang === "fr" ? "🌙 Nuit"    : "🌙 Night")}
              </div>
            </motion.div>

            {/* Book language selector */}
            <div className="flex flex-col gap-1.5">
              <span className="text-xs text-white/40">{t.bookLangLabel}</span>
              <div className="flex gap-1.5 flex-wrap">
                {BOOK_LANG_OPTIONS.map(opt => (
                  <motion.button
                    key={opt.id}
                    whileTap={{ scale: 0.94 }}
                    onClick={() => setBookLang(opt.id)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs border font-medium transition-colors ${bookLang === opt.id ? opt.activeColor : opt.color}`}
                  >
                    {opt.shortLabel}
                  </motion.button>
                ))}
              </div>
              <motion.p key={bookLang} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className={`text-xs font-medium ${activeBookLangOpt.activeColor.split(" ")[0]}`}>
                {activeBookLangOpt.label}
              </motion.p>
            </div>
          </div>
          <div className="backdrop-blur-md bg-white/8 border border-white/12 p-5 rounded-2xl flex flex-col gap-3">
            <h2 className="text-sm font-semibold flex items-center gap-2 text-amber-300"><Cloud className="w-4 h-4" />{t.yourWeather}</h2>
            {weatherLoading ? (
              <div className="flex-1 flex items-center justify-center py-2"><div className="w-5 h-5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" /></div>
            ) : weatherError ? (
              <div className="text-red-400 text-xs">{t.weatherError}</div>
            ) : weather ? (
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-4xl font-bold text-white">{Math.round(weather.temperature)}°C</div>
                  <div className="text-white/60 mt-1 text-sm">{weather.condition}</div>
                </div>
                <div className="text-amber-300/70">
                  {conditionGroup === "Rain" || conditionGroup === "Drizzle" ? <Droplets className="w-11 h-11" />
                    : conditionGroup === "Clear" ? <Thermometer className="w-11 h-11" />
                    : <Wind className="w-11 h-11" />}
                </div>
              </div>
            ) : null}
          </div>
        </motion.div>

        {/* ── Goodreads ── */}
        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <GoodreadsConnect onReadBooksChange={handleReadBooksChange} lang={lang} />
        </motion.div>

        {/* ── Age Group ── */}
        <motion.div className="backdrop-blur-md bg-white/8 border border-white/12 p-5 rounded-2xl flex flex-col gap-3"
          initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.33 }}>
          <h2 className="text-sm font-semibold flex items-center gap-2 text-amber-300"><Users className="w-4 h-4" />{t.ageGroup}</h2>
          <div className="flex flex-wrap gap-2">
            {AGE_GROUPS[lang].map(ag => (
              <button key={ag.id} onClick={() => setAgeGroup(prev => prev === ag.id ? "" : ag.id)}
                className={`text-sm px-3 py-1.5 rounded-full transition-all duration-200 border whitespace-nowrap ${
                  ageGroup === ag.id
                    ? "bg-amber-400 text-slate-900 border-amber-400 shadow-[0_0_14px_rgba(251,191,36,0.3)]"
                    : "bg-black/20 border-white/10 text-white/75 hover:bg-white/10 hover:border-white/20"}`}>
                {ag.label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* ── Mood & Category side by side ── */}
        <motion.div className="grid grid-cols-1 md:grid-cols-2 gap-4"
          initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.36 }}>
          {/* Mood */}
          <div className="backdrop-blur-md bg-white/8 border border-white/12 p-5 rounded-2xl flex flex-col gap-3">
            <h2 className="text-sm font-semibold flex items-center gap-2 text-amber-300"><Compass className="w-4 h-4" />{t.howFeel}</h2>
            <div className="overflow-y-auto flex flex-wrap gap-2 max-h-52 pr-1"
              style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(251,191,36,0.25) transparent" }}>
              {MOODS[lang].map((mood, idx) => (
                <button key={idx} onClick={() => setSelectedMoodIdx(idx)}
                  className={`text-sm px-3 py-1.5 rounded-full transition-all duration-200 border whitespace-nowrap ${
                    selectedMoodIdx === idx
                      ? "bg-amber-400 text-slate-900 border-amber-400 shadow-[0_0_14px_rgba(251,191,36,0.3)]"
                      : "bg-black/20 border-white/10 text-white/75 hover:bg-white/10 hover:border-white/20"}`}>
                  {mood}
                </button>
              ))}
            </div>
          </div>

          {/* Category */}
          <div className="backdrop-blur-md bg-white/8 border border-white/12 p-5 rounded-2xl flex flex-col gap-3">
            <h2 className="text-sm font-semibold flex items-center gap-2 text-amber-300"><BookOpen className="w-4 h-4" />{t.whatRead}</h2>
            <div className="overflow-y-auto flex flex-col gap-2 max-h-64 pl-1"
              style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(251,191,36,0.25) transparent" }}>

              {/* Adult categories grid */}
              <div className="grid grid-cols-2 gap-2">
                {CATEGORIES[lang].slice(0, CHILDREN_SECTION_START).map((cat, idx) => (
                  <button key={idx} onClick={() => setSelectedCatIdx(idx)}
                    className={`text-sm px-2.5 py-2 rounded-xl transition-all duration-200 border text-right leading-snug ${
                      selectedCatIdx === idx
                        ? "bg-amber-400 text-slate-900 border-amber-400 shadow-[0_0_14px_rgba(251,191,36,0.25)]"
                        : "bg-black/20 border-white/10 text-white/75 hover:bg-white/10 hover:border-white/20"}`}>
                    {cat}
                  </button>
                ))}
              </div>

              {/* Children's section divider */}
              <div className="flex items-center gap-2 pt-1">
                <div className="flex-1 h-px bg-gradient-to-r from-transparent via-pink-400/40 to-transparent" />
                <span className="text-[11px] font-semibold tracking-widest px-2 py-0.5 rounded-full bg-pink-400/12 border border-pink-400/25 text-pink-300/80">
                  {lang === "ar" ? "🧒 قسم الأطفال" : lang === "fr" ? "🧒 Section Enfants" : "🧒 Children's"}
                </span>
                <div className="flex-1 h-px bg-gradient-to-l from-transparent via-pink-400/40 to-transparent" />
              </div>

              {/* Children's categories grid */}
              <div className="grid grid-cols-3 gap-2">
                {CATEGORIES[lang].slice(CHILDREN_SECTION_START).map((cat, i) => {
                  const idx = CHILDREN_SECTION_START + i;
                  return (
                    <button key={idx} onClick={() => setSelectedCatIdx(idx)}
                      className={`text-xs px-2 py-2.5 rounded-xl transition-all duration-200 border text-center leading-snug ${
                        selectedCatIdx === idx
                          ? "bg-gradient-to-br from-pink-400 to-purple-500 text-white border-pink-400 shadow-[0_0_14px_rgba(236,72,153,0.35)]"
                          : "bg-pink-400/8 border-pink-400/18 text-pink-200/75 hover:bg-pink-400/15 hover:border-pink-400/30 hover:text-pink-100"}`}>
                      {cat}
                    </button>
                  );
                })}
              </div>

            </div>
          </div>
        </motion.div>

        {/* ── Book Length ── */}
        <motion.div className="backdrop-blur-md bg-white/8 border border-white/12 p-5 rounded-2xl flex flex-col gap-3"
          initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.40 }}>
          <h2 className="text-sm font-semibold flex items-center gap-2 text-amber-300"><BookMarked className="w-4 h-4" />{t.readingTime}</h2>
          <div className="flex gap-3">
            {lengthOptions.map(({ key, label }) => (
              <button key={key} onClick={() => setBookLength(key)}
                className={`flex-1 py-3 px-2 rounded-xl text-xs md:text-sm font-medium transition-all duration-200 border text-center ${
                  bookLength === key
                    ? "bg-amber-400 text-slate-900 border-amber-400 shadow-[0_0_14px_rgba(251,191,36,0.22)]"
                    : "bg-black/20 border-white/10 text-white/70 hover:bg-white/10 hover:border-white/20"}`}>
                {label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* ── Generate ── */}
        <motion.div className="flex flex-col items-center gap-2"
          initial={{ opacity: 0, scale: 0.92 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.44 }}>
          <button onClick={handleGenerate}
            disabled={!selectedMood || !selectedCategory || !weather || createRec.isPending}
            className="relative overflow-hidden bg-gradient-to-r from-amber-400 to-orange-500 text-slate-900 font-bold text-lg px-10 py-4 rounded-full shadow-[0_0_40px_rgba(251,191,36,0.22)] disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:scale-105 active:scale-95">
            <span className="flex items-center gap-3">
              {createRec.isPending
                ? <><div className="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin" />{t.generating}</>
                : <><Sparkles className="w-6 h-6" />{t.generate}</>}
            </span>
          </button>
          {readBooks.length > 0 && (
            <p className="text-xs text-emerald-400/75">{t.excludeNote.replace("{n}", String(readBooks.length))}</p>
          )}
        </motion.div>

        {/* ── Error ── */}
        <AnimatePresence>
          {showResults && createRec.isError && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="backdrop-blur-md bg-red-900/30 border border-red-400/30 p-6 rounded-2xl text-center text-red-300">
              <p className="text-lg font-semibold mb-1">
                {lang === "ar" ? "حدث خطأ" : lang === "fr" ? "Une erreur s'est produite" : "An error occurred"}
              </p>
              <button onClick={handleGenerate} className="mt-3 px-6 py-2 rounded-full bg-red-500/20 border border-red-400/30 text-red-300 hover:bg-red-500/30 transition-colors text-sm">
                {lang === "ar" ? "حاول مجدداً" : lang === "fr" ? "Réessayer" : "Try again"}
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── Results ── */}
        <AnimatePresence>
          {showResults && recommendation && (
            <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
              className="mt-2 space-y-6 pb-16">
              {/* Quote */}
              <div className="backdrop-blur-md bg-white/8 border border-amber-400/18 p-7 rounded-3xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-56 h-56 bg-amber-400/5 rounded-full blur-[50px] -z-10" />
                <Quote className="text-amber-400/35 w-9 h-9 mb-4" />
                <p className="text-xl md:text-2xl leading-relaxed text-amber-50 italic font-light">{recommendation.moodQuote}</p>
                <div className="mt-5 pt-5 border-t border-white/8">
                  <p className="text-white/65 leading-relaxed text-sm">{recommendation.aiAnalysis}</p>
                </div>
              </div>

              {/* Book Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {recommendation.books.map((book, idx) => {
                  const extBook = book as typeof book & { atmosphere?: string; length?: string };
                  const atmosLabel = extBook.atmosphere ? (ATMOS_LABELS[extBook.atmosphere]?.[bookLang] ?? null) : null;
                  const links = bookLinks(book.title, book.author);
                  const platforms = [
                    { label: "🎧 Libby",       sub: bookLang === "ar" ? "مجاني" : "Free",         href: links.libby,      free: true },
                    { label: "📖 Gutenberg",    sub: bookLang === "ar" ? "مجاني" : "Free",         href: links.gutenberg,  free: true },
                    { label: "🎧 StoryTel",     sub: bookLang === "ar" ? "اشتراك" : "Subscription", href: links.storytel,   free: false },
                    { label: "🎵 Audible",      sub: bookLang === "ar" ? "مدفوع" : "Paid",         href: links.audible,    free: false },
                    { label: "📱 Kindle",       sub: bookLang === "ar" ? "مدفوع" : "Paid",         href: links.kindle,     free: false },
                    { label: "📚 Google Play",  sub: bookLang === "ar" ? "مدفوع" : "Paid",         href: links.googlePlay, free: false },
                    { label: "📕 Kobo",         sub: bookLang === "ar" ? "مدفوع" : "Paid",         href: links.kobo,       free: false },
                  ];
                  return (
                    <motion.div key={idx} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.18 + 0.1 }}
                      className="backdrop-blur-md bg-white/8 border border-white/12 p-5 rounded-2xl flex flex-col gap-4">
                      {/* Badges */}
                      <div className="flex flex-wrap gap-1.5">
                        <span className="text-xs px-2 py-0.5 rounded-md bg-white/8 text-white/55 border border-white/10">{book.subcategory}</span>
                        {atmosLabel && (
                          <span className="text-xs px-2 py-0.5 rounded-md bg-amber-400/15 text-amber-300/90 border border-amber-400/20">{atmosLabel}</span>
                        )}
                        {extBook.length && (
                          <span className={`text-xs px-2 py-0.5 rounded-md border ${extBook.length === "قصير" ? "bg-emerald-500/12 border-emerald-500/25 text-emerald-300" : "bg-blue-500/12 border-blue-500/25 text-blue-300"}`}>
                            {extBook.length}
                          </span>
                        )}
                      </div>
                      {/* Title */}
                      <div>
                        <h3 className="text-lg font-bold text-amber-300 leading-snug">{book.title}</h3>
                        <p className="text-white/55 text-sm mt-0.5">{book.author}</p>
                        <p className="text-amber-400/60 text-xs mt-1">⭐ {book.rating}</p>
                      </div>
                      {/* Reason */}
                      <div className="flex-1 bg-black/18 rounded-xl p-3.5 text-sm leading-relaxed border border-white/5 text-white/75">
                        <span className="text-amber-300/75 font-semibold block mb-1 text-xs">{resultT.whyThisBook}</span>
                        {book.reason}
                      </div>
                      {/* Quote */}
                      <div className="italic text-white/48 text-sm border-r-2 border-amber-400/28 pr-3 py-0.5 leading-relaxed">{book.quote}</div>
                      {/* Platforms */}
                      <div className="flex flex-col gap-2 pt-1 border-t border-white/8">
                        <button onClick={() => setExpandedPlatforms(prev => { const n = new Set(prev); n.has(idx) ? n.delete(idx) : n.add(idx); return n; })}
                          className="flex items-center justify-between text-xs text-white/45 hover:text-white/70 transition-colors py-0.5">
                          <span className="flex items-center gap-1.5"><Headphones className="w-3 h-3" />{resultT.readOrListen}</span>
                          <span className="text-white/30">{expandedPlatforms.has(idx) ? "▲" : "▼"}</span>
                        </button>
                        {expandedPlatforms.has(idx) && (
                          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="grid grid-cols-2 gap-1.5">
                            {platforms.map(p => (
                              <a key={p.label} href={p.href} target="_blank" rel="noopener noreferrer"
                                className={`flex flex-col items-start px-2.5 py-2 rounded-xl border text-xs transition-all hover:scale-[1.02] active:scale-95 ${
                                  p.free ? "bg-emerald-500/10 border-emerald-500/22 text-emerald-300 hover:bg-emerald-500/18"
                                         : "bg-white/5 border-white/10 text-white/60 hover:bg-white/10 hover:text-white/80"}`}>
                                <span className="font-medium leading-tight">{p.label}</span>
                                <span className={`text-[10px] ${p.free ? "text-emerald-400/70" : "text-white/30"}`}>{p.sub}</span>
                              </a>
                            ))}
                          </motion.div>
                        )}
                        <div className="flex gap-2">
                          <a href={goodreadsUrl(book.title, book.author)} target="_blank" rel="noopener noreferrer"
                            className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl bg-[#553b08]/50 hover:bg-[#f4f1ea]/8 border border-amber-700/28 hover:border-amber-400/35 text-amber-300 text-xs font-medium transition-all">
                            <BookPlus className="w-3.5 h-3.5" />{resultT.iWantToRead}
                          </a>
                          <a href={`https://www.goodreads.com/search?q=${encodeURIComponent(book.title)}`} target="_blank" rel="noopener noreferrer"
                            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/45 hover:text-white/65 text-xs transition-all">
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}
