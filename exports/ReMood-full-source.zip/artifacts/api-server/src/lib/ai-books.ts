import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export type AiBook = {
  title: string;
  author: string;
  category: string;
  subcategory: string;
  rating: string;
  reason: string;
  quote: string;
  atmosphere?: string;
  length?: string;
};

// Seed phrases to bust the cache and force varied results each call
const SEED_PHRASES = [
  "overlooked gem", "hidden masterpiece", "unexpected classic", "rare find",
  "underrated novel", "forgotten treasure", "surprising pick", "fresh perspective",
  "bold recommendation", "unconventional choice", "timeless but unknown",
  "critically acclaimed", "reader favourite", "cult classic", "literary surprise",
];

function pickSeed(round: number): string {
  return SEED_PHRASES[round % SEED_PHRASES.length];
}

const LANG_LABELS: Record<string, string> = { ar: "Arabic", en: "English", fr: "French" };

export async function generateAiBooks(params: {
  mood: string;
  category: string;
  weather: string;
  timeOfDay: string;
  language: "ar" | "en" | "fr";
  ageGroup?: string;
  excludeTitles?: string[];
  bookLength?: string;
  searchRound?: number;
  count?: number;
}): Promise<AiBook[]> {
  const {
    mood, category, weather, timeOfDay, language = "ar",
    ageGroup, excludeTitles = [], bookLength, searchRound = 1, count = 5,
  } = params;

  const langLabel = LANG_LABELS[language] ?? "Arabic";
  const seed = pickSeed(searchRound);
  const exclude = excludeTitles.length
    ? `\nDo NOT suggest any of these books (already shown): ${excludeTitles.slice(0, 20).join("; ")}`
    : "";

  const lengthHint = bookLength && bookLength !== "أي طول" && bookLength !== "any"
    ? `\n- Prefer ${bookLength === "قصير" || bookLength === "short" ? "short" : "long"} books (under 300 pages / over 400 pages respectively).`
    : "";

  const ageHint = ageGroup
    ? `\n- Target age group: ${ageGroup}.`
    : "";

  const weatherMap: Record<string, string> = {
    Clear: "sunny and bright", Clouds: "overcast and cloudy", Rain: "rainy",
    Drizzle: "light drizzle", Thunderstorm: "stormy", Snow: "snowy",
    Atmosphere: "foggy or misty",
  };
  const weatherDesc = weatherMap[weather] ?? weather;

  const systemPrompt = `You are an expert multilingual book recommender. Always respond with ${langLabel} books only — books originally written in ${langLabel} or widely available in ${langLabel} translation. Your recommendations should feel fresh, varied, and personalised.`;

  const userPrompt = `Recommend exactly ${count} books. Think of something like a "${seed}".

Context:
- Reader's mood: "${mood}"
- Book category/genre: "${category}"
- Current weather: ${weatherDesc}
- Time of day: ${timeOfDay}${ageHint}${lengthHint}${exclude}

Return ONLY a JSON object with key "books" containing an array of ${count} objects, each with these fields:
{
  "title": "Book title (in ${langLabel})",
  "author": "Author full name",
  "category": "Genre label",
  "subcategory": "Sub-genre or theme",
  "rating": "4.X/5",
  "reason": "2-3 sentences explaining why this book perfectly fits the mood, weather, and category",
  "quote": "One memorable quote from the book",
  "atmosphere": "one of: adventure|mystery|romance|family|scifi|thriller|philosophical|spiritual|poetry|selfhelp|history|science|classic",
  "length": "${language === "ar" ? "قصير or طويل" : "short or long"}"
}

Important: Suggest DIFFERENT books on each call. Be creative and go beyond the obvious bestsellers.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user",   content: userPrompt },
      ],
      response_format: { type: "json_object" },
      temperature: 1,
      max_tokens: 2500,
    });

    const raw = response.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw);
    // Handle both {books:[...]} and direct array
    const arr: unknown[] = Array.isArray(parsed)
      ? parsed
      : (parsed.books ?? parsed.suggestions ?? parsed.recommendations ?? Object.values(parsed)[0] ?? []);

    if (!Array.isArray(arr)) return [];

    return arr.slice(0, count).map((b: any) => ({
      title:       b.title       ?? "Unknown Title",
      author:      b.author      ?? "Unknown Author",
      category:    b.category    ?? category,
      subcategory: b.subcategory ?? "",
      rating:      b.rating      ?? "4.5/5",
      reason:      b.reason      ?? "",
      quote:       b.quote       ?? "",
      atmosphere:  b.atmosphere,
      length:      b.length,
    }));
  } catch (err) {
    console.error("[ai-books] OpenAI error:", err);
    return [];
  }
}
