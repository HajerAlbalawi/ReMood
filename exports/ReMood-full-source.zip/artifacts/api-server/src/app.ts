import express, { type Express } from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { authMiddleware } from "./middlewares/authMiddleware";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(
  cors({
    credentials: true,
    origin: process.env.ALLOWED_ORIGIN ?? "http://localhost:5173",
  }),
);

// Rate limiting
app.use(
  "/api/recommendations",
  rateLimit({ windowMs: 60_000, max: 30 }),
);
app.use(
  "/api/weather",
  rateLimit({ windowMs: 60_000, max: 60 }),
);
app.use(
  "/api/goodreads",
  rateLimit({ windowMs: 60_000, max: 30 }),
);
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(authMiddleware);

app.use("/api", router);

export default app;
