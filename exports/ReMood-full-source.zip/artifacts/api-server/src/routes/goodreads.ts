import { Router, type IRouter } from "express";
const router: IRouter = Router();

interface GoodreadsBook {
  title: string;
  author: string;
  goodreadsId: string;
  coverUrl?: string;
  rating?: string;
}

// Minimal XML text-node extractor (no external dep needed for RSS)
function extractTag(xml: string, tag: string): string {
  const m = xml.match(new RegExp(`<${tag}[^>]*>(?:<\\!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?<\\/${tag}>`, "s"));
  return m ? m[1].trim() : "";
}

function extractAllItems(xml: string): string[] {
  const items: string[] = [];
  const re = /<item>([\s\S]*?)<\/item>/g;
  let match;
  while ((match = re.exec(xml)) !== null) {
    items.push(match[1]);
  }
  return items;
}

router.get("/goodreads/shelf", async (req, res): Promise<void> => {
  const userId = String(req.query.userId ?? "").trim();
  const shelf = String(req.query.shelf ?? "read").trim();

  if (!userId) {
    res.status(400).json({ error: "userId مطلوب" });
    return;
  }

  const validShelves = ["read", "to-read", "currently-reading"];
  if (!validShelves.includes(shelf)) {
    res.status(400).json({ error: "shelf غير صالح، يجب أن يكون: read أو to-read أو currently-reading" });
    return;
  }

  const rssUrl = `https://www.goodreads.com/review/list_rss/${encodeURIComponent(userId)}?shelf=${encodeURIComponent(shelf)}&per_page=200`;

  let xmlText: string;
  try {
    const response = await fetch(rssUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; BookGuide/1.0)",
        "Accept": "application/rss+xml, application/xml, text/xml",
      },
      signal: AbortSignal.timeout(10000),
    });

    if (!response.ok) {
      req.log.warn({ status: response.status, userId, shelf }, "Goodreads RSS non-OK");
      res.status(502).json({ error: "لم نتمكن من الوصول إلى Goodreads. تأكد من أن الملف الشخصي عام وأن المعرّف صحيح." });
      return;
    }

    xmlText = await response.text();
  } catch (err) {
    req.log.error({ err }, "Failed to fetch Goodreads RSS");
    res.status(502).json({ error: "فشل الاتصال بـ Goodreads" });
    return;
  }

  const items = extractAllItems(xmlText);
  const books: GoodreadsBook[] = items.map((item) => {
    // Goodreads RSS item fields
    const title = extractTag(item, "title");
    const author = extractTag(item, "author_name");
    const bookId = extractTag(item, "book_id");
    const imageUrl = extractTag(item, "book_large_image_url") || extractTag(item, "book_image_url");
    const userRating = extractTag(item, "user_rating");

    return {
      title: title.replace(/\s+/g, " ").trim(),
      author: author.replace(/\s+/g, " ").trim(),
      goodreadsId: bookId,
      coverUrl: imageUrl || undefined,
      rating: userRating || undefined,
    };
  }).filter((b) => b.title && b.author);

  res.json({
    userId,
    shelf,
    books,
    total: books.length,
  });
});

export default router;
