import { pgTable, serial, text, real, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const recommendationsTable = pgTable("recommendations", {
  id: serial("id").primaryKey(),
  city: text("city").notNull(),
  mood: text("mood").notNull(),
  category: text("category").notNull(),
  weatherCondition: text("weather_condition").notNull(),
  temperature: real("temperature").notNull(),
  books: jsonb("books").notNull(),
  moodQuote: text("mood_quote").notNull(),
  aiAnalysis: text("ai_analysis").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertRecommendationSchema = createInsertSchema(recommendationsTable).omit({ id: true, createdAt: true });
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;
export type RecommendationRow = typeof recommendationsTable.$inferSelect;
