# Threat Model

## Project Overview

ReMood (مرشد الكتب الذكي) is an Arabic-language book recommendation application. It fetches real-time weather data for a chosen city and, combined with the user's mood and category preferences, selects book recommendations from a static library of 80+ titles. Recommendations and their history are persisted in PostgreSQL.

The stack is: Node.js 24 / Express 5 API server, React (Vite) frontend, PostgreSQL + Drizzle ORM, TypeScript throughout, built as a pnpm workspace. The deployment is Replit Autoscale with **private** visibility (Replit's infrastructure restricts public internet access).

External service integrations:
- **open-meteo.com** — free weather API (no API key required)
- **Goodreads RSS** — optional read-shelf import (unauthenticated RSS feed, using a public user ID)

## Assets

- **Recommendation history (PostgreSQL)** — city, mood, weather, selected books, AI-generated quote and analysis for each session. No PII, but a tampered or full table could degrade the app.
- **Database connection string (`DATABASE_URL`)** — grants full read/write access to the PostgreSQL instance; must remain server-side only.
- **User's Goodreads user ID** — stored in `localStorage`; this is a public Goodreads identifier (not a credential), but leakage could allow third parties to query the user's reading shelf.

## Trust Boundaries

- **Browser → Express API** — all client requests cross this boundary. The API must validate and sanitize inputs; the client is untrusted.
- **Express API → PostgreSQL** — Drizzle ORM provides parameterized queries; the risk is ORM misuse (raw SQL) or unbounded inserts.
- **Express API → open-meteo.com** — coordinates are user-supplied and passed verbatim; the target host is hardcoded, limiting SSRF risk.
- **Express API → Goodreads RSS** — user-supplied `userId` is used in the URL; the host is hardcoded to goodreads.com.
- **Private deployment boundary** — Replit's infrastructure enforces that only authenticated Replit users with access to this repl can reach the deployed URLs; this is the primary access-control layer in the current architecture.

## Scan Anchors

- **Production entry points**: `artifacts/api-server/src/app.ts` (Express setup), `artifacts/api-server/src/routes/` (all routes)
- **Highest-risk route files**: `routes/recommendations.ts` (DB writes), `routes/goodreads.ts` (external HTTP fetch), `routes/weather.ts` (external HTTP fetch)
- **DB schema**: `lib/db/src/schema/recommendations.ts`
- **Input validation**: `lib/api-zod/src/generated/` (Zod schemas generated from OpenAPI spec)
- **Frontend**: `artifacts/book-weather/src/` — React SPA, no server-side rendering
- **Dev-only / mockup**: `artifacts/mockup-sandbox/` — design sandbox, not reachable in production

## Threat Categories

### Spoofing / Authentication

No application-level authentication exists on any API endpoint. The deployment's `private` visibility on Replit is the sole access control layer. If visibility is ever changed to `public`, every endpoint becomes fully open. This is an architectural gap that should be addressed before any public exposure.

All API endpoints (`/api/recommendations`, `/api/weather`, `/api/goodreads/shelf`, `/api/recommendations/stats`, `/api/healthz`) are callable by any request that reaches the server.

### Tampering

Input validation is handled by Zod schemas generated from the OpenAPI spec. The POST `/api/recommendations` body is parsed with `CreateRecommendationBody.parse()`, which rejects unknown types. Drizzle ORM uses parameterized queries throughout, preventing SQL injection.

However, no maximum-length constraints are enforced on string fields (`city`, `mood`, `category`, `weatherCondition`). Very large strings could be stored in the database, potentially causing degraded performance or storage exhaustion.

Latitude and longitude parameters for the weather endpoint are coerced to numbers by Zod but are not range-validated (−90/90 and −180/180). Out-of-range values are forwarded to the upstream open-meteo API, which will return its own error response.

### Information Disclosure

- No secrets are hardcoded in the source code. The database connection string is read from `process.env.DATABASE_URL`.
- The pino HTTP logger strips query strings from URL logs, reducing accidental parameter logging.
- Error responses from the Goodreads and weather proxy routes return user-facing Arabic messages without stack traces.
- React's JSX rendering auto-escapes all dynamic content, preventing XSS from stored recommendation data.

### Denial of Service

No rate limiting is configured on any endpoint. The `POST /api/recommendations` endpoint writes to the database on every call; an attacker with access to the private deployment can spam it to fill the database. Similarly, the `/api/weather` and `/api/goodreads/shelf` endpoints act as open proxies to external services, enabling abuse of those upstream APIs.

### Elevation of Privilege

No role-based access control exists. There are no admin endpoints to protect. All users (Replit-authenticated) have identical access to all API operations.

### Security Misconfiguration

CORS is configured with `app.use(cors())` using all defaults, which produces `Access-Control-Allow-Origin: *`. Any web page loaded in a user's browser can make cross-origin requests to the API without restriction.
